
import React, { useState, useMemo } from 'react';
import { useBusiness, useAuth } from '../App';
import { GoogleGenAI } from "@google/genai";
import { 
  BarChart3, 
  Download, 
  TrendingUp, 
  PieChart as PieIcon,
  ArrowUp,
  Info,
  Sparkles,
  Lock,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie,
  Legend
} from 'recharts';

export default function Reports() {
  const { sales, products } = useBusiness();
  const { user } = useAuth();
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  const reportData = useMemo(() => {
    const revenue = sales.reduce((sum, s) => sum + s.totalPrice, 0);
    const profit = sales.reduce((sum, s) => sum + s.totalProfit, 0);
    const cost = revenue - profit;
    const margin = revenue > 0 ? (profit / revenue) * 100 : 0;

    const categoryMap: any = {};
    sales.forEach(sale => {
      const product = products.find(p => p.id === sale.productId);
      const cat = product?.category || 'Uncategorized';
      categoryMap[cat] = (categoryMap[cat] || 0) + sale.totalPrice;
    });

    const categoryData = Object.keys(categoryMap).map(name => ({
      name,
      value: categoryMap[name]
    }));

    return {
      revenue,
      profit,
      cost,
      margin,
      categoryData
    };
  }, [sales, products]);

  const generateAiInsight = async () => {
    if (user?.subscription !== 'pro') return;
    setIsLoadingAi(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Analyze this small business data for owner ${user.name}:
      - Total Revenue: $${reportData.revenue}
      - Net Profit: $${reportData.profit}
      - Profit Margin: ${reportData.margin.toFixed(1)}%
      - Categories Performance: ${JSON.stringify(reportData.categoryData)}
      - Inventory Status: ${products.length} items, ${products.filter(p => p.stockQuantity <= p.minStockLevel).length} low stock.
      Provide 3 concise, actionable growth insights. Focus on profit maximization and tax estimation tips. Keep it professional.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });

      setAiInsight(response.text || "Unable to generate insights at this time.");
    } catch (err) {
      console.error(err);
      setAiInsight("AI Engine error. Please check your connection.");
    } finally {
      setIsLoadingAi(false);
    }
  };

  const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Financial Reports</h1>
          <p className="text-slate-500">Ownership-isolated performance metrics.</p>
        </div>
        <button className="flex items-center justify-center gap-2 px-6 py-3 bg-white border border-slate-200 text-slate-700 font-bold rounded-2xl hover:bg-slate-50 transition-all shadow-sm">
          <Download size={20} />
          Export PDF
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
            <p className="text-slate-500 font-medium mb-1">Total Gross Revenue</p>
            <h3 className="text-3xl font-bold text-slate-900 mb-6">${reportData.revenue.toLocaleString()}</h3>
            <div className="flex items-center gap-2 text-emerald-600 font-semibold text-sm">
               <ArrowUp size={16} />
               <span>Real-time ownership data</span>
            </div>
         </div>
         <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
            <p className="text-slate-500 font-medium mb-1">Net Profit Margin</p>
            <h3 className="text-3xl font-bold text-indigo-600 mb-6">{reportData.margin.toFixed(1)}%</h3>
            <div className="flex items-center gap-2 text-emerald-600 font-semibold text-sm">
               <ArrowUp size={16} />
               <span>Calculated per user</span>
            </div>
         </div>
         <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
            <p className="text-slate-500 font-medium mb-1">Cost of Goods Sold</p>
            <h3 className="text-3xl font-bold text-rose-600 mb-6">${reportData.cost.toLocaleString()}</h3>
            <div className="flex items-center gap-2 text-rose-500 font-semibold text-sm">
               <Info size={16} />
               <span>Expenses from your inventory</span>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
         {/* AI Intelligence Gated Section */}
         <div className="bg-gradient-to-br from-indigo-600 to-violet-700 p-8 rounded-[40px] text-white shadow-2xl relative overflow-hidden h-full">
            <div className="relative z-10">
               <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2 px-3 py-1 bg-white/20 rounded-full text-xs font-bold uppercase tracking-wider">
                    <Sparkles size={14} />
                    <span>AI Business Intelligence</span>
                  </div>
                  {user?.subscription === 'pro' ? (
                     <button 
                       onClick={generateAiInsight}
                       disabled={isLoadingAi}
                       className="p-2 hover:bg-white/10 rounded-xl transition-all disabled:opacity-50"
                     >
                       <RefreshCw size={20} className={isLoadingAi ? 'animate-spin' : ''} />
                     </button>
                  ) : (
                     <div className="flex items-center gap-1 text-[10px] font-bold text-amber-300">
                        <Lock size={12} />
                        PRO ONLY
                     </div>
                  )}
               </div>

               {user?.subscription === 'pro' ? (
                  <div className="space-y-4">
                     {!aiInsight && !isLoadingAi && (
                        <div className="py-12 text-center">
                           <p className="text-indigo-100 mb-6 text-lg">Harness your sales data to uncover hidden growth opportunities.</p>
                           <button 
                             onClick={generateAiInsight}
                             className="px-8 py-3 bg-white text-indigo-600 font-bold rounded-2xl hover:bg-indigo-50 transition-all shadow-xl"
                           >
                              Analyze My Data
                           </button>
                        </div>
                     )}
                     {isLoadingAi && (
                        <div className="py-12 flex flex-col items-center gap-4">
                           <Loader2 className="animate-spin text-white" size={40} />
                           <p className="text-indigo-100 animate-pulse">Scanning your business performance...</p>
                        </div>
                     )}
                     {aiInsight && !isLoadingAi && (
                        <div className="prose prose-invert max-w-none">
                           <div className="p-6 bg-white/10 rounded-3xl border border-white/10 backdrop-blur-sm">
                              <p className="whitespace-pre-wrap leading-relaxed text-indigo-50">{aiInsight}</p>
                           </div>
                        </div>
                     )}
                  </div>
               ) : (
                  <div className="py-12 text-center space-y-6">
                     <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-white/20">
                        <Lock size={32} className="text-indigo-200" />
                     </div>
                     <h3 className="text-2xl font-bold">Predictive AI Insights</h3>
                     <p className="text-indigo-100 max-w-xs mx-auto text-sm">
                        Upgrade to Pro to get AI-powered inventory forecasts, tax estimations, and personalized growth strategies.
                     </p>
                     <button className="px-8 py-3 bg-amber-500 text-white font-bold rounded-2xl hover:bg-amber-600 transition-all shadow-xl">
                        Upgrade to Pro Plan
                     </button>
                  </div>
               )}
            </div>
            <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-white/10 rounded-full blur-3xl" />
         </div>

         <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm flex flex-col">
            <div className="flex items-center justify-between mb-8">
               <div>
                  <h3 className="text-lg font-bold text-slate-900">Profitability Breakdown</h3>
                  <p className="text-sm text-slate-500">Revenue, Costs & Net Profit</p>
               </div>
               <BarChart3 size={20} className="text-slate-300" />
            </div>
            <div className="h-[300px] w-full">
               <ResponsiveContainer width="100%" height="100%">
                  <BarChart 
                    data={[
                      { name: 'Revenue', value: reportData.revenue, color: '#4f46e5' },
                      { name: 'Costs', value: reportData.cost, color: '#f43f5e' },
                      { name: 'Profit', value: reportData.profit, color: '#10b981' },
                    ]}
                  >
                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                     <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                     <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                     <Tooltip cursor={{fill: 'transparent'}} />
                     <Bar dataKey="value" radius={[12, 12, 0, 0]}>
                        {[1, 2, 3].map((entry, index) => (
                           <Cell key={`cell-${index}`} fill={['#4f46e5', '#f43f5e', '#10b981'][index]} />
                        ))}
                     </Bar>
                  </BarChart>
               </ResponsiveContainer>
            </div>
         </div>
      </div>
    </div>
  );
}
