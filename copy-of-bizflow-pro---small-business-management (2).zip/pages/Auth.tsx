
import React, { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../App';
import { TrendingUp, Mail, Lock, User, ArrowRight, AlertCircle, CheckCircle2, ShieldAlert } from 'lucide-react';

export default function Auth({ mode }: { mode: 'login' | 'signup' }) {
  const { login, signup } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({ 
    name: '', 
    email: '', 
    password: '',
    isPro: (location.state as any)?.sub === 'pro'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (mode === 'signup') {
      if (!formData.name || !formData.email || !formData.password) {
        setError('Please fill in all fields');
        return;
      }
      
      // Strict Separation: Public signup is strictly for the 'user' role.
      // Admin accounts must be provisioned through system seeds or database management.
      const role = 'user'; 
      const sub = formData.isPro ? 'pro' : 'free';
      
      if (signup(formData.name, formData.email, formData.password, role, sub)) {
        navigate('/dashboard');
      } else {
        setError('Email already exists');
      }
    } else {
      // Login logic handles redirection based on the existing user's role stored in the database.
      if (login(formData.email, formData.password)) {
        const users = JSON.parse(localStorage.getItem('biz_users') || '[]');
        const u = users.find((x: any) => x.email === formData.email);
        if (u) {
          navigate(u.role === 'admin' ? '/admin' : '/dashboard');
        }
      } else {
        setError('Invalid email or password');
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <Link to="/" className="inline-flex items-center gap-2 mb-6 hover:opacity-80 transition-opacity">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
              <TrendingUp size={24} />
            </div>
            <span className="text-2xl font-black bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600">BizFlow Pro</span>
          </Link>
          <h1 className="text-3xl font-extrabold text-slate-900 mb-2">
            {mode === 'signup' ? 'Create your account' : 'Welcome back'}
          </h1>
          <p className="text-slate-500">
            {mode === 'signup' ? 'Professional data isolation for your business.' : 'Sign in to access your secure dashboard.'}
          </p>
        </div>

        <div className="bg-white p-8 rounded-[40px] shadow-2xl shadow-slate-200/50 border border-slate-100">
          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 text-sm font-medium">
                <AlertCircle size={18} />
                {error}
              </div>
            )}

            {mode === 'signup' && (
              <div className="space-y-1.5">
                <label className="text-sm font-bold text-slate-700 ml-1">Full Name</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input
                    type="text"
                    required
                    placeholder="Enter your name"
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-sm font-bold text-slate-700 ml-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input
                  type="email"
                  required
                  placeholder="name@company.com"
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-bold text-slate-700 ml-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
              </div>
            </div>

            {mode === 'signup' && (
              <div className="pt-2">
                 <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl cursor-pointer hover:bg-indigo-50 transition-all border border-transparent hover:border-indigo-100">
                    <input 
                      type="checkbox" 
                      className="w-5 h-5 accent-indigo-600" 
                      checked={formData.isPro}
                      onChange={e => setFormData({...formData, isPro: e.target.checked})}
                    />
                    <div className="flex-1">
                       <p className="text-sm font-bold text-slate-900">Sign up for Pro Plan</p>
                       <p className="text-[10px] text-slate-500">Includes Gemini AI Analysis Tools</p>
                    </div>
                 </label>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all hover:scale-[1.02] active:scale-95 shadow-xl shadow-indigo-100 flex items-center justify-center gap-2"
            >
              {mode === 'signup' ? 'Create Account' : 'Sign In'}
              <ArrowRight size={20} />
            </button>
          </form>

          <div className="mt-8 text-center pt-6 border-t border-slate-100">
            <p className="text-slate-500 font-medium">
              {mode === 'signup' ? 'Already have an account?' : "Don't have an account yet?"}
              <Link
                to={mode === 'signup' ? '/login' : '/signup'}
                className="ml-2 text-indigo-600 font-bold hover:underline"
              >
                {mode === 'signup' ? 'Log in here' : 'Create one now'}
              </Link>
            </p>
          </div>
        </div>

        <div className="mt-8 flex items-center justify-center gap-4 opacity-40">
           <ShieldAlert size={14} />
           <span className="text-[10px] font-bold uppercase tracking-widest">Ownership isolation verified</span>
        </div>
      </div>
    </div>
  );
}
