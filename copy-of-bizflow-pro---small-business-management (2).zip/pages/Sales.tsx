
import React, { useState, useMemo } from 'react';
import { useBusiness } from '../App';
import { 
  Plus, 
  Search, 
  ShoppingCart, 
  ArrowRight, 
  X,
  History,
  TrendingUp,
  CreditCard,
  User,
  Package,
  Check
} from 'lucide-react';
import { Product } from '../types';

export default function Sales() {
  const { products, sales, recordSale } = useBusiness();
  const [isRecording, setIsRecording] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');

  const selectedProduct = products.find(p => p.id === selectedProductId);

  const handleRecord = () => {
    if (!selectedProductId || quantity <= 0) return;
    recordSale(selectedProductId, quantity);
    setIsRecording(false);
    setSelectedProductId('');
    setQuantity(1);
  };

  const filteredHistory = sales.filter(s => 
    s.productName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Sales</h1>
          <p className="text-slate-500">Track transactions and record new sales.</p>
        </div>
        <button 
          onClick={() => setIsRecording(true)}
          className="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-bold hover:bg-indigo-700 transition-all hover:scale-105 shadow-lg shadow-indigo-100 flex items-center justify-center gap-2"
        >
          <ShoppingCart size={20} />
          New Transaction
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sales History */}
        <div className="lg:col-span-2 space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="Search in history..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all shadow-sm"
            />
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <History size={18} className="text-slate-400" />
                History
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider">Product</th>
                    <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider">Qty</th>
                    <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider">Total</th>
                    <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider">Profit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredHistory.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-20 text-center text-slate-400">
                        No transactions recorded yet.
                      </td>
                    </tr>
                  ) : (
                    filteredHistory.map(sale => (
                      <tr key={sale.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4 text-sm text-slate-500 whitespace-nowrap">
                          {new Date(sale.timestamp).toLocaleDateString()}
                          <span className="block text-[10px] text-slate-300">
                            {new Date(sale.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-bold text-slate-900">{sale.productName}</span>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-700">{sale.quantity}</td>
                        <td className="px-6 py-4 text-sm font-bold text-slate-900">${sale.totalPrice.toFixed(2)}</td>
                        <td className="px-6 py-4">
                          <span className="text-sm font-bold text-emerald-600">+${sale.totalProfit.toFixed(2)}</span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Stats Summary Sidebar */}
        <div className="space-y-6">
           <div className="bg-indigo-600 p-8 rounded-[40px] text-white shadow-2xl shadow-indigo-200 relative overflow-hidden">
              <div className="relative z-10">
                <p className="text-indigo-100 text-sm font-medium mb-1">Today's Revenue</p>
                <h3 className="text-4xl font-extrabold mb-6">
                  ${sales.filter(s => new Date(s.timestamp).toDateString() === new Date().toDateString())
                    .reduce((sum, s) => sum + s.totalPrice, 0).toFixed(2)}
                </h3>
                <div className="flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full w-fit">
                  <TrendingUp size={14} />
                  <span className="text-xs font-bold uppercase tracking-wider">Live Tracking</span>
                </div>
              </div>
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <ShoppingCart size={120} strokeWidth={1} />
              </div>
           </div>

           <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
             <h3 className="text-lg font-bold text-slate-900 mb-4">Quick Stats</h3>
             <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl">
                   <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-600">
                        <Package size={16} />
                      </div>
                      <span className="text-sm text-slate-600">Total Units Sold</span>
                   </div>
                   <span className="text-sm font-bold text-slate-900">
                     {sales.reduce((sum, s) => sum + s.quantity, 0)}
                   </span>
                </div>
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl">
                   <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center text-indigo-600">
                        <CreditCard size={16} />
                      </div>
                      <span className="text-sm text-slate-600">Avg. Order Value</span>
                   </div>
                   <span className="text-sm font-bold text-slate-900">
                     ${sales.length > 0 ? (sales.reduce((sum, s) => sum + s.totalPrice, 0) / sales.length).toFixed(2) : '0.00'}
                   </span>
                </div>
             </div>
           </div>
        </div>
      </div>

      {/* New Transaction Modal */}
      {isRecording && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setIsRecording(false)} />
          <div className="bg-white rounded-[40px] w-full max-w-lg relative z-10 shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
            <div className="bg-indigo-600 p-8 text-white relative">
               <button onClick={() => setIsRecording(false)} className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-full transition-colors">
                 <X size={20} />
               </button>
               <h3 className="text-2xl font-bold mb-1">New Sale</h3>
               <p className="text-indigo-100 text-sm">Record a direct customer purchase.</p>
            </div>
            <div className="p-8 space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">Select Product</label>
                  <select 
                    value={selectedProductId}
                    onChange={e => setSelectedProductId(e.target.value)}
                    className="w-full px-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all appearance-none"
                  >
                    <option value="">-- Choose a product --</option>
                    {products.map(p => (
                      <option key={p.id} value={p.id} disabled={p.stockQuantity <= 0}>
                        {p.name} (${p.sellingPrice.toFixed(2)}) {p.stockQuantity <= 0 ? '(Out of Stock)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
                
                {selectedProduct && (
                   <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-2xl flex items-center justify-between">
                      <div>
                        <p className="text-xs font-bold text-indigo-400 uppercase tracking-wider mb-0.5">Stock Available</p>
                        <p className="text-lg font-bold text-indigo-700">{selectedProduct.stockQuantity} units</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-bold text-indigo-400 uppercase tracking-wider mb-0.5">Unit Price</p>
                        <p className="text-lg font-bold text-indigo-700">${selectedProduct.sellingPrice.toFixed(2)}</p>
                      </div>
                   </div>
                )}

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">Quantity</label>
                  <input 
                    type="number" 
                    min="1"
                    max={selectedProduct?.stockQuantity || 1}
                    value={quantity} 
                    onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full px-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>

              {selectedProduct && (
                 <div className="pt-2">
                    <div className="flex items-center justify-between mb-2">
                       <span className="text-slate-500">Subtotal</span>
                       <span className="font-bold text-slate-900">${(selectedProduct.sellingPrice * quantity).toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between py-4 border-t border-slate-100">
                       <span className="text-lg font-bold text-slate-900">Total</span>
                       <span className="text-2xl font-black text-indigo-600">${(selectedProduct.sellingPrice * quantity).toFixed(2)}</span>
                    </div>
                 </div>
              )}

              <button 
                onClick={handleRecord}
                disabled={!selectedProductId || (selectedProduct && quantity > selectedProduct.stockQuantity)}
                className="w-full py-4 text-lg font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-2xl transition-all disabled:opacity-50 shadow-xl shadow-indigo-100 flex items-center justify-center gap-3"
              >
                Complete Sale
                <Check size={20} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
