import React, { useState } from 'react';
import { useAuth, useBusiness } from '../App';
import { 
  Database, 
  Download, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  Trash2,
  RefreshCw,
  FileJson,
  ShieldCheck
} from 'lucide-react';

export default function UserSettings() {
  const { user } = useAuth();
  const { products, sales, reloadBusinessData } = useBusiness();
  const [status, setStatus] = useState<'idle' | 'success' | 'error' | 'loading'>('idle');
  const [message, setMessage] = useState('');

  const exportData = () => {
    try {
      const data = {
        exportDate: new Date().toISOString(),
        ownerId: user?.id,
        products,
        sales
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `bizflow_backup_${user?.name?.toLowerCase().replace(/\s/g, '_')}_${new Date().getTime()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setStatus('success');
      setMessage('Data exported successfully!');
      setTimeout(() => setStatus('idle'), 3000);
    } catch (e) {
      setStatus('error');
      setMessage('Export failed. Please try again.');
    }
  };

  const importData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        
        // Strict Validation: Ensure data matches current owner or is legacy
        if (!data.products || !data.sales) throw new Error("Invalid file format");
        
        const prefix = "owner_" + user?.id + "_";
        
        // Update localStorage
        localStorage.setItem(prefix + "products", JSON.stringify(data.products));
        localStorage.setItem(prefix + "sales", JSON.stringify(data.sales));
        
        // Refresh context
        reloadBusinessData();
        
        setStatus('success');
        setMessage('Data restored successfully!');
        setTimeout(() => setStatus('idle'), 5000);
      } catch (err) {
        setStatus('error');
        setMessage('Invalid backup file. Please ensure it is a BizFlow JSON export.');
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // Reset input
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">User Settings</h1>
        <p className="text-slate-500">Manage your business profile and data portability.</p>
      </header>

      {status !== 'idle' && (
        <div className={`p-4 rounded-2xl flex items-center gap-3 font-medium animate-in slide-in-from-top-2 ${
          status === 'success' ? 'bg-emerald-50 border border-emerald-100 text-emerald-600' :
          status === 'error' ? 'bg-rose-50 border border-rose-100 text-rose-600' : 'bg-indigo-50 text-indigo-600'
        }`}>
          {status === 'success' ? <CheckCircle2 size={20} /> : <AlertCircle size={20} />}
          {message}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Data Portability */}
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Database size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Data Management</h3>
          </div>
          
          <div className="space-y-4">
            <p className="text-sm text-slate-600 leading-relaxed">
              BizFlow allows you to keep a permanent copy of your records. Take your business data wherever you go.
            </p>
            
            <div className="flex flex-col gap-3">
              <button 
                onClick={exportData}
                className="flex items-center justify-between px-6 py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 group"
              >
                <div className="flex items-center gap-3">
                  <Download size={20} className="group-hover:translate-y-0.5 transition-transform" />
                  <span>Export JSON Backup</span>
                </div>
              </button>
              
              <label className="flex items-center justify-between px-6 py-4 bg-slate-100 text-slate-700 font-bold rounded-2xl hover:bg-slate-200 transition-all cursor-pointer group">
                <div className="flex items-center gap-3">
                  <Upload size={20} className="group-hover:-translate-y-0.5 transition-transform" />
                  <span>Restore from File</span>
                </div>
                <input type="file" accept=".json" onChange={importData} className="hidden" />
              </label>
            </div>
          </div>
        </div>

        {/* Account Info */}
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <ShieldCheck size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Account Integrity</h3>
          </div>
          
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-2xl">
              <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Authenticated As</p>
              <p className="text-sm font-bold text-slate-900">{user?.name}</p>
              <p className="text-xs text-slate-500">{user?.email}</p>
            </div>
            
            <div className="p-4 bg-slate-50 rounded-2xl">
              <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Subscription Level</p>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-indigo-600 uppercase tracking-tight">{user?.subscription} plan</span>
                {user?.subscription === 'free' && (
                  <button className="text-xs font-bold text-amber-600 hover:underline">Upgrade Now</button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Danger Zone */}
        <div className="md:col-span-2 bg-rose-50/30 p-8 rounded-[40px] border border-rose-100 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1">
            <h4 className="text-lg font-bold text-rose-900">Reset Business Records</h4>
            <p className="text-sm text-rose-700/70">Wipe all local inventory and sales history. This action cannot be undone.</p>
          </div>
          <button 
            onClick={() => {
              if (window.confirm("ARE YOU ABSOLUTELY SURE? This will delete all products and sales forever.")) {
                const prefix = "owner_" + user?.id + "_";
                localStorage.removeItem(prefix + "products");
                localStorage.removeItem(prefix + "sales");
                reloadBusinessData();
                setStatus('success');
                setMessage('All data cleared.');
              }
            }}
            className="px-6 py-3 bg-rose-600 text-white font-bold rounded-2xl hover:bg-rose-700 transition-all flex items-center gap-2"
          >
            <Trash2 size={18} />
            Wipe Business Data
          </button>
        </div>
      </div>
    </div>
  );
}