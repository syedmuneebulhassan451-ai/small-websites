import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  DollarSign, 
  Percent, 
  Globe, 
  Save, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle,
  Database,
  Download,
  Upload,
  Activity
} from 'lucide-react';

interface SystemSettings {
  taxRate: number;
  currencySymbol: string;
  platformName: string;
  maintenanceMode: boolean;
}

export default function AdminSettings() {
  const [settings, setSettings] = useState<SystemSettings>({
    taxRate: 15,
    currencySymbol: '$',
    platformName: 'BizFlow Pro',
    maintenanceMode: false
  });
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    const storedSettings = localStorage.getItem('biz_system_settings');
    if (storedSettings) {
      setSettings(JSON.parse(storedSettings));
    }
  }, []);

  const handleSave = () => {
    setIsSaving(true);
    setSaveStatus('idle');
    
    // Simulate API delay
    setTimeout(() => {
      try {
        localStorage.setItem('biz_system_settings', JSON.stringify(settings));
        setSaveStatus('success');
      } catch (e) {
        setSaveStatus('error');
      } finally {
        setIsSaving(false);
        setTimeout(() => setSaveStatus('idle'), 3000);
      }
    }, 800);
  };

  const exportSystemVault = () => {
    const fullState: Record<string, string | null> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('biz_') || key?.startsWith('owner_')) {
        fullState[key] = localStorage.getItem(key);
      }
    }
    
    const data = {
      platform: "BizFlow Pro",
      version: "1.0",
      timestamp: new Date().toISOString(),
      vault: fullState
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bizflow_admin_vault_${new Date().getTime()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importSystemVault = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (!data.vault) throw new Error("Invalid vault file");
        
        if (window.confirm("DANGER: This will overwrite the entire platform database. Continue?")) {
          Object.entries(data.vault).forEach(([key, value]) => {
            if (value) localStorage.setItem(key, value as string);
          });
          setSaveStatus('success');
          window.location.reload();
        }
      } catch (err) {
        setSaveStatus('error');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">System Settings</h1>
          <p className="text-slate-500">Configure global parameters and platform defaults.</p>
        </div>
        <button 
          onClick={handleSave}
          disabled={isSaving}
          className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all disabled:opacity-50 shadow-lg shadow-indigo-100"
        >
          {isSaving ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <Save size={20} />
          )}
          {isSaving ? 'Saving...' : 'Save Changes'}
        </button>
      </header>

      {saveStatus === 'success' && (
        <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center gap-3 text-emerald-600 font-medium animate-in slide-in-from-top-2">
          <CheckCircle2 size={20} />
          System updated successfully!
        </div>
      )}

      {saveStatus === 'error' && (
        <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 font-medium animate-in slide-in-from-top-2">
          <AlertCircle size={20} />
          Failed to process system request.
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Financial Settings */}
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <DollarSign size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Financial Defaults</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Default Tax Rate (%)</label>
              <div className="relative">
                <Percent className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="number" 
                  value={settings.taxRate}
                  onChange={e => setSettings({...settings, taxRate: parseFloat(e.target.value) || 0})}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Currency Symbol</label>
              <input 
                type="text" 
                value={settings.currencySymbol}
                onChange={e => setSettings({...settings, currencySymbol: e.target.value})}
                maxLength={3}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                placeholder="$"
              />
            </div>
          </div>
        </div>

        {/* Global Data Vault */}
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Database size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Global Data Vault</h3>
          </div>
          
          <div className="space-y-4">
             <p className="text-sm text-slate-500 leading-relaxed">
               Manage all platform records including user accounts, inventories, and global configurations.
             </p>
             <div className="flex flex-col gap-2">
                <button 
                  onClick={exportSystemVault}
                  className="w-full flex items-center gap-3 px-4 py-3 bg-indigo-50 text-indigo-700 rounded-xl font-bold hover:bg-indigo-100 transition-all border border-indigo-100"
                >
                  <Download size={18} />
                  Download Full Backup
                </button>
                <label className="w-full flex items-center gap-3 px-4 py-3 bg-amber-50 text-amber-700 rounded-xl font-bold hover:bg-amber-100 transition-all border border-amber-100 cursor-pointer">
                  <Upload size={18} />
                  Restore System State
                  <input type="file" accept=".json" onChange={importSystemVault} className="hidden" />
                </label>
             </div>
          </div>
        </div>

        {/* Platform Branding */}
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Globe size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Branding & Platform</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Platform Name</label>
              <input 
                type="text" 
                value={settings.platformName}
                onChange={e => setSettings({...settings, platformName: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              />
            </div>
            
            <div className="pt-4">
              <label className="flex items-center justify-between cursor-pointer group">
                <div>
                  <p className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">Maintenance Mode</p>
                  <p className="text-xs text-slate-500">Temporarily disable user access</p>
                </div>
                <div className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={settings.maintenanceMode}
                    onChange={e => setSettings({...settings, maintenanceMode: e.target.checked})}
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* System Logs */}
        <div className="md:col-span-2 bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <ShieldCheck size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Security & Integrity</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <p className="text-xs font-bold text-slate-400 uppercase mb-1">Last Config Update</p>
              <p className="text-sm font-semibold text-slate-700">{new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <p className="text-xs font-bold text-slate-400 uppercase mb-1">Encrypted Sessions</p>
              <p className="text-sm font-semibold text-emerald-600">Active (AES-256 Mock)</p>
            </div>
          </div>
          <div className="bg-slate-50 p-4 rounded-2xl text-[10px] font-mono text-slate-500 leading-relaxed overflow-x-auto whitespace-pre">
            [SYS_LOG] Saver data initialized...<br/>
            [SYS_LOG] Portability tools provisioned...<br/>
            [SYS_LOG] Vault encryption active...<br/>
            [SYS_LOG] Ready for administrative input.
          </div>
        </div>
      </div>
    </div>
  );
}