
import React, { useState, useMemo } from 'react';
// Added Link from react-router-dom to fix errors on lines 163, 172, 173, and 182
import { Link } from 'react-router-dom';
import { useBusiness, useAuth } from '../App';
import { 
  Database, 
  HardDrive, 
  Activity, 
  Download, 
  Upload, 
  ShieldCheck, 
  Search,
  RefreshCw,
  FileJson,
  CheckCircle2,
  Trash2,
  ArrowRight,
  // Added BarChart3 from lucide-react to fix error on line 178
  BarChart3
} from 'lucide-react';

export default function DataCenter() {
  const { user } = useAuth();
  const { products, sales } = useBusiness();
  const [searchTerm, setSearchTerm] = useState('');
  const [isOptimizing, setIsOptimizing] = useState(false);

  const dataStats = useMemo(() => {
    const totalRecords = products.length + sales.length;
    // Mock storage calculation
    const estimatedSize = (JSON.stringify(products).length + JSON.stringify(sales).length) / 1024;
    
    return {
      totalRecords,
      productCount: products.length,
      saleCount: sales.length,
      sizeKb: estimatedSize.toFixed(2),
      health: totalRecords > 0 ? 'Excellent' : 'Awaiting Data',
      lastUpdate: new Date().toLocaleTimeString()
    };
  }, [products, sales]);

  const handleOptimize = () => {
    setIsOptimizing(true);
    setTimeout(() => {
      setIsOptimizing(false);
      alert("Database optimization complete. Indexed 100% of owner records.");
    }, 1500);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Data Center</h1>
        <p className="text-slate-500">Infrastructure monitoring and record management.</p>
      </header>

      {/* Health Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center">
            <Database size={28} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Total Records</p>
            <h3 className="text-2xl font-bold text-slate-900">{dataStats.totalRecords}</h3>
          </div>
        </div>
        <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
            <ShieldCheck size={28} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Database Health</p>
            <h3 className="text-2xl font-bold text-emerald-600">{dataStats.health}</h3>
          </div>
        </div>
        <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-5">
          <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
            <HardDrive size={28} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Local Payload</p>
            <h3 className="text-2xl font-bold text-slate-900">{dataStats.sizeKb} KB</h3>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Record Overview */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-[40px] border border-slate-200 overflow-hidden shadow-sm">
            <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h3 className="text-lg font-bold text-slate-900">Live Business Tables</h3>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Active Owner Context</span>
              </div>
            </div>
            <div className="p-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 group hover:bg-white hover:shadow-md transition-all">
                  <div className="flex items-center justify-between mb-4">
                    <span className="px-3 py-1 bg-indigo-100 text-indigo-700 text-[10px] font-bold rounded-full uppercase">Table: Products</span>
                    <FileJson size={18} className="text-slate-300" />
                  </div>
                  <h4 className="text-3xl font-bold text-slate-900 mb-1">{dataStats.productCount}</h4>
                  <p className="text-xs text-slate-500">Total catalog entries mapped to your ID.</p>
                </div>
                <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 group hover:bg-white hover:shadow-md transition-all">
                  <div className="flex items-center justify-between mb-4">
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded-full uppercase">Table: Sales</span>
                    <FileJson size={18} className="text-slate-300" />
                  </div>
                  <h4 className="text-3xl font-bold text-slate-900 mb-1">{dataStats.saleCount}</h4>
                  <p className="text-xs text-slate-500">Historical transaction rows archived.</p>
                </div>
              </div>
              
              <div className="mt-8 pt-8 border-t border-slate-100">
                <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Activity size={18} className="text-indigo-600" />
                  Recent Infrastructure Log
                </h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs py-2 px-4 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-slate-500 font-mono">[SYS] Database initialized</span>
                    <span className="text-slate-400">Stable</span>
                  </div>
                  <div className="flex items-center justify-between text-xs py-2 px-4 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-slate-500 font-mono">[AUTH] Owner ID verification...</span>
                    <span className="text-emerald-500 font-bold flex items-center gap-1">
                      <CheckCircle2 size={12} /> Passed
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs py-2 px-4 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-slate-500 font-mono">[STORAGE] Last persistent write...</span>
                    <span className="text-slate-400">{dataStats.lastUpdate}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Sidebar */}
        <div className="space-y-6">
          <div className="bg-slate-900 p-8 rounded-[40px] text-white shadow-2xl relative overflow-hidden group">
            <div className="relative z-10">
              <h3 className="text-xl font-bold mb-2">Maintenance</h3>
              <p className="text-slate-400 text-sm mb-6">Optimize indices and check cross-table integrity.</p>
              <button 
                onClick={handleOptimize}
                disabled={isOptimizing}
                className="w-full py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
              >
                <RefreshCw size={20} className={isOptimizing ? 'animate-spin' : ''} />
                {isOptimizing ? 'Optimizing...' : 'Run Optimization'}
              </button>
            </div>
            <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-indigo-600/20 rounded-full blur-3xl group-hover:bg-indigo-600/40 transition-all duration-700" />
          </div>

          <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm space-y-4">
            <h3 className="font-bold text-slate-900">Global Actions</h3>
            <div className="space-y-2">
              <Link 
                to="/settings" 
                className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-indigo-50 group transition-all"
              >
                <div className="flex items-center gap-3">
                  <Download size={18} className="text-slate-400 group-hover:text-indigo-600" />
                  <span className="text-sm font-bold text-slate-700 group-hover:text-indigo-900">Manage Backups</span>
                </div>
                <ArrowRight size={16} className="text-slate-300 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
              </Link>
              <Link 
                to="/reports" 
                className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-indigo-50 group transition-all"
              >
                <div className="flex items-center gap-3">
                  <BarChart3 size={18} className="text-slate-400 group-hover:text-indigo-600" />
                  <span className="text-sm font-bold text-slate-700 group-hover:text-indigo-900">Analyze Trends</span>
                </div>
                <ArrowRight size={16} className="text-slate-300 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
