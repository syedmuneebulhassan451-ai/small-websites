import React, { useMemo, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Users, 
  ShieldCheck, 
  Settings, 
  Activity,
  Filter,
  Search,
  Clock
} from 'lucide-react';
import { User } from '../types';

export default function AdminDashboard() {
  const [users, setUsers] = useState<User[]>([]);
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [subFilter, setSubFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    const storedUsers = JSON.parse(localStorage.getItem('biz_users') || '[]');
    setUsers(storedUsers);
  }, []);

  const filteredUsers = useMemo(() => {
    return users.filter(u => {
      const matchesRole = roleFilter === 'all' || u.role === roleFilter;
      const matchesSub = subFilter === 'all' || u.subscription === subFilter;
      const matchesSearch = u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           u.email.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesRole && matchesSub && matchesSearch;
    });
  }, [users, roleFilter, subFilter, searchQuery]);

  const stats = useMemo(() => {
    return {
      totalUsers: users.length,
      admins: users.filter(u => u.role === 'admin').length,
      proUsers: users.filter(u => u.subscription === 'pro').length,
      systemHealth: 'Optimal'
    };
  }, [users]);

  const formatLastActive = (timestamp?: number) => {
    if (!timestamp) return 'Never';
    const date = new Date(timestamp);
    return date.toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Admin Command Center</h1>
        <p className="text-slate-500">System-wide overview and user management.</p>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="p-3 w-fit rounded-2xl bg-indigo-50 text-indigo-600 mb-4">
            <Users size={24} />
          </div>
          <p className="text-sm font-medium text-slate-500">Total Users</p>
          <h3 className="text-2xl font-bold text-slate-900">{stats.totalUsers}</h3>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="p-3 w-fit rounded-2xl bg-amber-50 text-amber-600 mb-4">
            <ShieldCheck size={24} />
          </div>
          <p className="text-sm font-medium text-slate-500">Pro Subscriptions</p>
          <h3 className="text-2xl font-bold text-slate-900">{stats.proUsers}</h3>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="p-3 w-fit rounded-2xl bg-emerald-50 text-emerald-600 mb-4">
            <Activity size={24} />
          </div>
          <p className="text-sm font-medium text-slate-500">System Status</p>
          <h3 className="text-2xl font-bold text-slate-900">{stats.systemHealth}</h3>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="p-3 w-fit rounded-2xl bg-rose-50 text-rose-600 mb-4">
            <Settings size={24} />
          </div>
          <p className="text-sm font-medium text-slate-500">Global Settings</p>
          <Link to="/admin/settings" className="text-sm font-bold text-indigo-600 hover:underline">Configure Platform</Link>
        </div>
      </div>

      <div className="bg-white rounded-[40px] border border-slate-200 overflow-hidden shadow-sm">
        <div className="px-8 py-6 border-b border-slate-100 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <h3 className="text-xl font-bold text-slate-900">Registered Users</h3>
            <button className="text-sm font-bold text-indigo-600 px-4 py-2 hover:bg-indigo-50 rounded-xl transition-all">Export Directory</button>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <div className="relative flex-1 w-full sm:w-auto">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Search name or email..." 
                className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-3 w-full sm:w-auto overflow-x-auto">
              <div className="flex items-center gap-2 whitespace-nowrap">
                <Filter size={16} className="text-slate-400" />
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Filter By:</span>
              </div>
              <select 
                value={roleFilter} 
                onChange={e => setRoleFilter(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-semibold text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer"
              >
                <option value="all">All Roles</option>
                <option value="user">Users</option>
                <option value="admin">Admins</option>
              </select>
              <select 
                value={subFilter} 
                onChange={e => setSubFilter(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-semibold text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer"
              >
                <option value="all">All Plans</option>
                <option value="free">Free Plan</option>
                <option value="pro">Pro Plan</option>
              </select>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-xs font-bold uppercase tracking-wider">
                <th className="px-8 py-4">User Details</th>
                <th className="px-8 py-4">Role</th>
                <th className="px-8 py-4">Plan</th>
                <th className="px-8 py-4">
                  <div className="flex items-center gap-2">
                    <Clock size={14} /> Last Active
                  </div>
                </th>
                <th className="px-8 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-8 py-12 text-center text-slate-400 font-medium">
                    No users found matching your filters.
                  </td>
                </tr>
              ) : (
                filteredUsers.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-600 group-hover:bg-indigo-100 group-hover:text-indigo-600 transition-colors">
                          {u.name ? u.name[0] : '?'}
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">{u.name}</p>
                          <p className="text-xs text-slate-500">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-tight border ${
                        u.role === 'admin' ? 'bg-rose-50 text-rose-600 border-rose-100' : 'bg-slate-50 text-slate-600 border-slate-200'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="px-8 py-6">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-tight border ${
                        u.subscription === 'pro' ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-slate-50 text-slate-400 border-slate-200'
                      }`}>
                        {u.subscription}
                      </span>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex flex-col">
                        <span className="text-sm font-medium text-slate-700">{formatLastActive(u.lastActive)}</span>
                        {u.lastActive && (Date.now() - u.lastActive < 300000) && (
                          <span className="text-[10px] text-emerald-600 font-bold uppercase flex items-center gap-1">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            Online Now
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <button className="text-sm font-semibold text-slate-400 hover:text-indigo-600 transition-colors">Manage</button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}