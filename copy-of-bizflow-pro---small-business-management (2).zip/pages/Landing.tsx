
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../App';
import { 
  CheckCircle2, 
  BarChart2, 
  Zap, 
  TrendingUp, 
  ArrowRight,
  ShieldCheck,
  LayoutDashboard,
  Package,
  XCircle
} from 'lucide-react';

const FeatureCard = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
  <div className="p-8 bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
    <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 mb-6">
      <Icon size={24} />
    </div>
    <h3 className="text-xl font-bold text-slate-900 mb-3">{title}</h3>
    <p className="text-slate-600 leading-relaxed">{description}</p>
  </div>
);

export default function Landing() {
  const { user } = useAuth();
  const entryPath = user ? (user.role === 'admin' ? '/admin' : '/dashboard') : '/login';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <nav className="max-w-7xl mx-auto w-full px-6 h-20 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
            <TrendingUp size={18} />
          </div>
          <span className="text-xl font-bold text-slate-900">BizFlow Pro</span>
        </div>
        <div className="hidden md:flex items-center gap-8">
          <Link to={entryPath} className="bg-indigo-600 text-white px-6 py-2.5 rounded-full text-sm font-semibold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
            {user ? 'Dashboard' : 'Sign In'}
          </Link>
        </div>
      </nav>

      <section className="relative pt-12 pb-24 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
          <div className="z-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 rounded-full text-indigo-700 text-sm font-semibold mb-8">
              <ShieldCheck size={16} />
              <span>Strict Data Privacy Enabled</span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-extrabold text-slate-900 leading-tight mb-8">
              Smarter tools for <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">your business only.</span>
            </h1>
            <p className="text-xl text-slate-600 mb-10 leading-relaxed max-w-xl">
              Professional inventory and sales management with absolute data isolation. Your data, your insights, your success.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to={user ? entryPath : '/signup'} className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-indigo-600 text-white rounded-2xl text-lg font-bold hover:bg-indigo-700 transition-all hover:scale-105 shadow-xl shadow-indigo-100">
                Start Free Trial
                <ArrowRight size={20} />
              </Link>
            </div>
          </div>
          <div className="relative">
             <div className="relative z-10 bg-white p-4 rounded-[40px] shadow-2xl border border-slate-100">
                <img 
                  src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1200&auto=format&fit=crop" 
                  alt="Dashboard Preview" 
                  className="rounded-[32px] w-full"
                />
             </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-4">Enterprise-grade Security</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">Absolute ownership filtering ensures your business secrets stay yours. Not even the admin can see your raw competitive data.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={ShieldCheck}
              title="Data Ownership"
              description="Every record is isolated by a strict owner_id. No data leaks, ever."
            />
            <FeatureCard 
              icon={Package}
              title="Inventory Guard"
              description="Real-time tracking of cost, margin, and stock levels tailored for your catalog."
            />
            <FeatureCard 
              icon={Zap}
              title="AI Intelligence"
              description="Pro users get predictive insights from Gemini to stay ahead of market shifts."
            />
          </div>
        </div>
      </section>

      <section id="pricing" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-4">Simple, Transparent Plans</h2>
            <p className="text-lg text-slate-600">Choose the intelligence level your business needs.</p>
          </div>
          <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
             <div className="p-10 bg-white rounded-3xl border border-slate-200 flex flex-col">
                <h3 className="text-xl font-bold text-slate-900 mb-2">Free Plan</h3>
                <div className="mb-6 flex items-baseline gap-1">
                  <span className="text-4xl font-bold">$0</span>
                  <span className="text-slate-500">/mo</span>
                </div>
                <ul className="space-y-4 mb-10 flex-1">
                  <li className="flex items-center gap-3 text-slate-600"><CheckCircle2 size={18} className="text-indigo-500" /> Full Inventory Tracking</li>
                  <li className="flex items-center gap-3 text-slate-600"><CheckCircle2 size={18} className="text-indigo-500" /> Basic Sales Reports</li>
                  <li className="flex items-center gap-3 text-slate-400 line-through"><XCircle size={18} /> Gemini AI Insights</li>
                  <li className="flex items-center gap-3 text-slate-400 line-through"><XCircle size={18} /> Predictive Forecasting</li>
                </ul>
                <Link to="/signup" className="w-full py-4 text-center bg-slate-100 text-slate-900 rounded-2xl font-bold hover:bg-slate-200 transition-all">
                  Sign Up Free
                </Link>
             </div>
             <div className="p-10 bg-indigo-600 rounded-3xl text-white shadow-2xl shadow-indigo-200 flex flex-col relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4">
                  <span className="bg-indigo-400/30 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">Most Popular</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Pro Plan</h3>
                <div className="mb-6 flex items-baseline gap-1">
                  <span className="text-4xl font-bold">$19</span>
                  <span className="text-indigo-200">/mo</span>
                </div>
                <ul className="space-y-4 mb-10 flex-1">
                  <li className="flex items-center gap-3"><CheckCircle2 size={18} className="text-indigo-300" /> All Free Features</li>
                  <li className="flex items-center gap-3"><CheckCircle2 size={18} className="text-indigo-300" /> Gemini AI Business Advisor</li>
                  <li className="flex items-center gap-3"><CheckCircle2 size={18} className="text-indigo-300" /> Profit & Tax Estimations</li>
                  <li className="flex items-center gap-3"><CheckCircle2 size={18} className="text-indigo-300" /> Priority Support</li>
                </ul>
                <Link to="/signup" state={{ sub: 'pro' }} className="w-full py-4 text-center bg-white text-indigo-600 rounded-2xl font-bold hover:bg-indigo-50 transition-all">
                  Get Pro Access
                </Link>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
}
